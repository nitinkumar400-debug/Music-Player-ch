package com.chaudhary.music

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.border
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.launch

private val Ink = Color(0xFF071B1A)
private val Panel = Color(0xB8183431)
private val Accent = Color(0xFFB9F36A)
private val Lilac = Color(0xFF67D8C5)

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val uri: Uri,
    val art: Uri?,
    val duration: Long
) {
    val key: String get() = id.toString()
}

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { mediaController = controllerFuture?.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, secondary = Lilac, background = Ink,
                    surface = Color(0xFF102B28), onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                MusicApp(controller = mediaController)
            }
        }
    }

    override fun onDestroy() {
        mediaController?.let { MediaController.releaseFuture(controllerFuture!!) }
        super.onDestroy()
    }
}

@Composable
private fun MusicApp(controller: MediaController?) {
    val context = LocalContext.current
    var permissionGranted by remember { mutableStateOf(hasAudioPermission(context)) }
    var songs by remember { mutableStateOf(emptyList<Song>()) }
    var selectedSong by remember { mutableStateOf<Song?>(null) }
    var search by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showEqualizer by remember { mutableStateOf(false) }
    var playerTick by remember { mutableIntStateOf(0) }
    var activeTab by remember { mutableStateOf("Library") }
    val prefs = remember { context.getSharedPreferences("sangeet_settings", Context.MODE_PRIVATE) }
    var backgroundUri by remember { mutableStateOf(prefs.getString("background_uri", null)) }
    var nightMode by remember { mutableStateOf(prefs.getBoolean("night_mode", true)) }
    val backgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            backgroundUri = uri.toString()
            prefs.edit().putString("background_uri", backgroundUri).apply()
        }
    }

    LaunchedEffect(controller) {
        while (true) {
            playerTick++
            kotlinx.coroutines.delay(500)
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permissionGranted = it
    }
    LaunchedEffect(Unit) {
        if (!permissionGranted) {
            val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
            permissionLauncher.launch(p)
        }
    }
    LaunchedEffect(permissionGranted) {
        if (permissionGranted) songs = loadSongs(context)
    }

    val currentUri = controller?.currentMediaItem?.localConfiguration?.uri
    val _playerRefresh = playerTick
    val currentSong = songs.firstOrNull { it.uri == currentUri } ?: selectedSong
    val visibleSongs = songs.filter {
        it.title.contains(search, true) || it.artist.contains(search, true) || it.album.contains(search, true)
    }

    CompositionLocalProvider(LocalContentColor provides (if (nightMode) Color.White else Color(0xFF142522))) {
    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(if (nightMode) listOf(Color(0xFF061817), Color(0xFF102B28), Color(0xFF071B1A)) else listOf(Color(0xFFF1F8F4), Color(0xFFDDEFE7), Color(0xFFF7FBF8)))
    )) {
        if (backgroundUri != null) {
            AsyncImage(model = Uri.parse(backgroundUri), contentDescription = null,
                modifier = Modifier.fillMaxSize().alpha(.22f))
        }
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars).windowInsetsPadding(WindowInsets.navigationBars).padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Accent, Lilac))), contentAlignment = Alignment.Center) {
                    if (currentSong?.art != null) {
                        AsyncImage(model = currentSong.art, contentDescription = "Now playing artwork", modifier = Modifier.fillMaxSize())
                    } else {
                        Icon(Icons.Default.GraphicEq, null, tint = Ink, modifier = Modifier.size(28.dp))
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("Sangeet", style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Cursive,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        letterSpacing = 1.1.sp
                    ), fontWeight = FontWeight.Bold, color = if (nightMode) Color.White else Color(0xFF102A25))
                    Text("Meri Pasand Ke Gaane", color = if (nightMode) Lilac else Color(0xFF287C6C), style = MaterialTheme.typography.labelMedium, letterSpacing = .35.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                GlassIcon(Icons.Default.Search, "Search songs") { showSearch = !showSearch; if (!showSearch) search = "" }
                Spacer(Modifier.width(5.dp))
                AnimatedEqualizerButton { showEqualizer = true }
                Spacer(Modifier.width(5.dp))
                GlassIcon(Icons.Default.Settings, "Settings") { showSettings = true }
            }
            Spacer(Modifier.height(22.dp))
            if (showSearch) {
                OutlinedTextField(
                    value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search songs or artists") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = { IconButton(onClick = { search = ""; showSearch = false }) { Icon(Icons.Default.Close, null) } },
                    singleLine = true, shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = Color.White.copy(.12f), focusedBorderColor = Accent,
                        unfocusedContainerColor = Panel, focusedContainerColor = Panel
                    )
                )
                Spacer(Modifier.height(15.dp))
            }
            if (activeTab == "Library") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text("Gaane", style = MaterialTheme.typography.headlineLarge.copy(
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Cursive,
                        letterSpacing = 1.8.sp
                    ), fontWeight = FontWeight.ExtraBold, color = Accent)
                    Spacer(Modifier.width(12.dp))
                    Text("${visibleSongs.size} TRACKS", color = Lilac, style = MaterialTheme.typography.labelMedium, letterSpacing = 1.4.sp)
                }
                Spacer(Modifier.height(16.dp))
                if (!permissionGranted) {
                    EmptyState("Allow audio access", "Sangeet needs permission to show songs on this device.") {
                        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
                        permissionLauncher.launch(p)
                    }
                } else if (songs.isEmpty()) {
                    EmptyState("No songs found", "Add audio files to your device, then try again.") { songs = loadSongs(context) }
                } else if (visibleSongs.isEmpty()) {
                    EmptyState("No matching songs", "Try another song or artist name.") { search = "" }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        items(visibleSongs, key = { it.id }) { song ->
                            SongRow(song, isPlaying = currentSong?.id == song.id && controller?.isPlaying == true) {
                                playSongList(controller, songs, song)
                            }
                        }
                    }
                }
            } else {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    if (currentSong != null) {
                        AlbumThumb(currentSong.art, Modifier.fillMaxWidth(.72f).aspectRatio(1f), large = true)
                        Spacer(Modifier.height(22.dp))
                        Text(currentSong.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(currentSong.artist, color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.height(18.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                            IconButton(onClick = { controller?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, modifier = Modifier.size(34.dp)) }
                            IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }, modifier = Modifier.size(68.dp).background(Accent, CircleShape)) {
                                Icon(if (controller?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Ink, modifier = Modifier.size(38.dp))
                            }
                            IconButton(onClick = { controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, modifier = Modifier.size(34.dp)) }
                        }
                        TextButton(onClick = { selectedSong = currentSong }) { Text("OPEN FULL PLAYER", color = Accent, letterSpacing = 1.sp) }
                    } else {
                        Icon(Icons.Default.MusicNote, null, tint = Lilac, modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Nothing playing yet", fontWeight = FontWeight.Bold)
                        Text("Choose a song from your Library", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { activeTab = "Library" }) { Text("Browse songs") }
                    }
                }
            }
            // The old Library / Now Playing navigation bar is replaced by a persistent mini player.
            if (currentSong != null) {
                Spacer(Modifier.height(10.dp))
                MiniPlayer(currentSong, controller,
                    onExpand = { selectedSong = currentSong },
                    onNext = { controller?.seekToNextMediaItem() },
                    onPrevious = { controller?.seekToPreviousMediaItem() })
                Spacer(Modifier.height(8.dp))
            }
        }
        if (selectedSong != null) {
            NowPlayingDialog(song = currentSong ?: selectedSong!!, controller = controller,
                onClose = { selectedSong = null; activeTab = "Library" })
        }
        if (showSettings) {
            SettingsDialog(backgroundUri = backgroundUri, nightMode = nightMode,
                onToggleNightMode = { nightMode = it; prefs.edit().putBoolean("night_mode", it).apply() },
                onChooseBackground = { backgroundPicker.launch(arrayOf("image/*")) },
                onResetBackground = { backgroundUri = null; prefs.edit().remove("background_uri").apply() },
                onDismiss = { showSettings = false })
        }
        if (showEqualizer) EqualizerDialog(audioSessionId = context.getSharedPreferences("playback", Context.MODE_PRIVATE).getInt("audio_session_id", 0), onDismiss = { showEqualizer = false })
    }
    }
}

@Composable
private fun BottomNavigationBar(activeTab: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 58.dp).clip(RoundedCornerShape(24.dp)).background(Color.White.copy(.08f)).padding(5.dp)) {
        listOf("Library" to Icons.Default.LibraryMusic, "Now Playing" to Icons.Default.PlayCircle).forEach { (label, icon) ->
            val selected = activeTab == label
            Row(Modifier.weight(1f).clip(RoundedCornerShape(19.dp))
                .background(if (selected) Color(0xFF23594F) else Color.Transparent)
                .clickable { onSelect(label) }.padding(vertical = 13.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = if (selected) Accent else Color(0xFFAAC8C0), modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(7.dp))
                Text(label, color = if (selected) Color.White else Color(0xFFAAC8C0), fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun AnimatedEqualizerButton(onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "eq-icon")
    val heights = (0..4).map { i ->
        transition.animateFloat(initialValue = .25f + i * .08f, targetValue = .85f - i * .08f,
            animationSpec = infiniteRepeatable(tween(420 + i * 90), repeatMode = RepeatMode.Reverse), label = "eq-$i")
    }
    Row(Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(.10f)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
        val colors = listOf(Color(0xFFFF5D8F), Color(0xFFFFB84D), Color(0xFFB9F36A), Color(0xFF4DD9C8), Color(0xFF7A9CFF))
        heights.forEachIndexed { index, value ->
            Box(Modifier.weight(1f).fillMaxHeight(value.value).clip(RoundedCornerShape(4.dp)).background(colors[index]))
        }
    }
}

private fun hasAudioPermission(context: Context): Boolean {
    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
}

private fun loadSongs(context: Context): List<Song> {
    val result = mutableListOf<Song>()
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
    )
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    val cursor: Cursor? = context.contentResolver.query(collection, projection, selection, null, sort)
    cursor?.use {
        val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
        while (it.moveToNext()) {
            val id = it.getLong(idCol)
            val albumId = it.getLong(albumIdCol)
            val uri = Uri.withAppendedPath(collection, id.toString())
            val art = Uri.parse("content://media/external/audio/albumart/$albumId")
            result += Song(id, it.getString(titleCol) ?: "Unknown title",
                it.getString(artistCol) ?: "Unknown artist",
                it.getString(albumCol) ?: "Unknown album", uri, art,
                it.getLong(durationCol))
        }
    }
    return result
}

private fun playSongList(controller: MediaController?, songs: List<Song>, selected: Song) {
    if (controller == null) return
    val items = songs.map { song ->
        MediaItem.Builder().setUri(song.uri).setMediaId(song.id.toString())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist)
                .setAlbumTitle(song.album).setArtworkUri(song.art).build()).build()
    }
    val index = songs.indexOfFirst { it.id == selected.id }.coerceAtLeast(0)
    controller.setMediaItems(items, index, 0L)
    controller.prepare()
    controller.play()
}

@Composable
private fun SongRow(song: Song, isPlaying: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xCC173A35), Color(0xAA142A2B))))
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumThumb(song.art, Modifier.size(54.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text("${song.artist}  •  ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall)
        }
        if (isPlaying) Icon(Icons.Default.GraphicEq, null, tint = Accent)
        else Text(formatTime(song.duration), color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun MiniPlayer(song: Song, controller: MediaController?, onExpand: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xEE1D5A50), Color(0xDD173A3A))))
            .clickable(onClick = onExpand).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumThumb(song.art, Modifier.size(48.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(song.artist, color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
        }
        IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null) }
        IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }) {
            Icon(if (controller?.isPlaying == true) Icons.Default.PlayCircleFilled else Icons.Default.PauseCircleFilled, null, tint = Accent, modifier = Modifier.size(38.dp))
        }
        IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null) }
    }
}

@Composable
private fun NowPlayingDialog(song: Song, controller: MediaController?, onClose: () -> Unit) {
    var position by remember { mutableLongStateOf(controller?.currentPosition ?: 0L) }
    var duration by remember { mutableLongStateOf(controller?.duration?.coerceAtLeast(0L) ?: song.duration) }
    var visible by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { visible = true }
    LaunchedEffect(controller) {
        while (true) {
            position = controller?.currentPosition ?: 0L
            duration = (controller?.duration ?: song.duration).coerceAtLeast(1L)
            kotlinx.coroutines.delay(500)
        }
    }
    val dismiss: () -> Unit = {
        scope.launch {
            visible = false
            kotlinx.coroutines.delay(220)
            onClose()
        }
    }
    androidx.compose.ui.window.Dialog(onDismissRequest = dismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(280)) + scaleIn(initialScale = .94f, animationSpec = tween(280)),
            exit = fadeOut(tween(200)) + scaleOut(targetScale = .96f, animationSpec = tween(200))
        ) {
            Box(
                Modifier.fillMaxWidth().fillMaxHeight(.94f).padding(12.dp)
                    .clip(RoundedCornerShape(32.dp))
            ) {
                // The currently playing track's artwork fills the popup and softly blurs behind the controls.
                if (song.art != null) {
                    AsyncImage(model = song.art, contentDescription = null,
                        modifier = Modifier.fillMaxSize().blur(34.dp).alpha(.62f))
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xB817443D), Color(0xF5071B1A)))))
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("NOW PLAYING", letterSpacing = 2.sp, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .82f))
                        IconButton(onClick = dismiss, modifier = Modifier.size(44.dp).background(Color.White.copy(.13f), CircleShape)) {
                            Icon(Icons.Default.Close, contentDescription = "Close player", tint = Color.White)
                        }
                    }
                    AnimatedArtworkFrame(song.art, Modifier.fillMaxWidth(.82f).aspectRatio(1f))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(song.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                        Text(song.artist, color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Column {
                        Slider(
                            value = position.toFloat().coerceIn(0f, duration.toFloat()),
                            onValueChange = { position = it.toLong() },
                            onValueChangeFinished = { controller?.seekTo(position) },
                            valueRange = 0f..duration.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color.White.copy(.30f))
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(formatTime(position), color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.labelSmall)
                            Text(formatTime(duration), color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { controller?.seekToPreviousMediaItem() }, modifier = Modifier.size(66.dp).background(Color.White.copy(.14f), CircleShape)) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = Color.White, modifier = Modifier.size(42.dp))
                        }
                        IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }, modifier = Modifier.size(88.dp).background(Brush.linearGradient(listOf(Accent, Lilac)), CircleShape)) {
                            Icon(if (controller?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (controller?.isPlaying == true) "Pause" else "Play", tint = Ink, modifier = Modifier.size(50.dp))
                        }
                        IconButton(onClick = { controller?.seekToNextMediaItem() }, modifier = Modifier.size(66.dp).background(Color.White.copy(.14f), CircleShape)) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(42.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsDialog(
    backgroundUri: String?, nightMode: Boolean, onToggleNightMode: (Boolean) -> Unit,
    onChooseBackground: () -> Unit, onResetBackground: () -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF17443D), Color(0xFF0A211F))))
            .verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null) }
            }
            Text("SANGEET PLAYER", color = Accent, style = MaterialTheme.typography.labelMedium, letterSpacing = 1.2.sp)
            Text("Personalise the look of your music player.", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Appearance", fontWeight = FontWeight.SemiBold)
                    Text(if (nightMode) "Night mode" else "Day mode", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
                }
                Switch(checked = nightMode, onCheckedChange = onToggleNightMode)
            }
            Divider(color = Color.White.copy(.12f))
            Text("APP BACKGROUND", color = Accent, style = MaterialTheme.typography.labelMedium)
            if (backgroundUri != null) {
                AsyncImage(model = Uri.parse(backgroundUri), contentDescription = "Selected background",
                    modifier = Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(16.dp)))
            }
            Button(onClick = onChooseBackground, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Wallpaper, null); Spacer(Modifier.width(8.dp)); Text(if (backgroundUri == null) "Choose background photo" else "Change background photo")
            }
            if (backgroundUri != null) {
                OutlinedButton(onClick = onResetBackground, modifier = Modifier.fillMaxWidth()) { Text("Remove custom background") }
            }
            Divider(color = Color.White.copy(.12f))
            Text("Sangeet  •  Version 1.11", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
            Text("Created by Nitin Chaudhary", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun EqualizerDialog(audioSessionId: Int, onDismiss: () -> Unit) {
    var enabled by remember { mutableStateOf(false) }
    var level by remember { mutableFloatStateOf(0.55f) }
    var bass by remember { mutableFloatStateOf(0.30f) }
    var selectedPreset by remember { mutableStateOf("Rock") }
    val bandValues = remember { mutableStateListOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f) }
    var surround by remember { mutableStateOf(false) }
    var dolby by remember { mutableStateOf(false) }
    var eq by remember { mutableStateOf<Equalizer?>(null) }
    var bassFx by remember { mutableStateOf<BassBoost?>(null) }
    var virtualizer by remember { mutableStateOf<Virtualizer?>(null) }
    val presets = listOf("Rock", "Dance", "Pop", "Jazz", "Classical")
    DisposableEffect(audioSessionId) {
        if (audioSessionId > 0) {
            try {
                eq = Equalizer(0, audioSessionId).apply { enabled = false }
                bassFx = BassBoost(0, audioSessionId).apply { enabled = false }
                virtualizer = Virtualizer(0, audioSessionId).apply { enabled = false }
            } catch (_: Exception) { }
        }
        onDispose {
            try { eq?.release(); bassFx?.release(); virtualizer?.release() } catch (_: Exception) { }
            eq = null; bassFx = null; virtualizer = null
        }
    }
    fun applyPreset(name: String) {
        selectedPreset = name
        val profiles = mapOf(
            "Rock" to listOf(5, 3, -1, -2, 2, 4, 5, 5, 4, 3),
            "Dance" to listOf(5, 4, 2, 0, 2, 4, 5, 4, 3, 2),
            "Pop" to listOf(-1, 1, 3, 4, 3, 0, -1, -1, 1, 2),
            "Jazz" to listOf(3, 2, 0, 2, -2, -2, 0, 2, 3, 4),
            "Classical" to listOf(4, 3, 2, 1, -1, -1, 0, 2, 3, 4)
        )
        try {
            val values = profiles[name] ?: profiles.getValue("Rock")
            for (uiBand in 0 until 10) bandValues[uiBand] = values[uiBand].toFloat() / 12f
            val effect = eq ?: return
            val range = effect.bandLevelRange
            val hardwareBands = effect.numberOfBands.toInt().coerceAtLeast(1)
            for (band in 0 until hardwareBands) {
                val uiIndex = if (hardwareBands == 1) 0 else (band * 9f / (hardwareBands - 1)).toInt().coerceIn(0, 9)
                val db = values[uiIndex]
                val scaled = (db * 100).coerceIn(range[0].toInt(), range[1].toInt())
                effect.setBandLevel(band.toShort(), scaled.toShort())
            }
            effect.enabled = enabled
        } catch (_: Exception) { }
    }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF17443D), Color(0xFF0A211F))))
            .verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Equalizer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null) }
            }
            Text("SOUND PRESETS", color = Accent, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                presets.take(3).forEach { preset ->
                    FilterChip(selected = selectedPreset == preset, onClick = { applyPreset(preset) }, label = { Text(preset, style = MaterialTheme.typography.labelSmall) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                presets.drop(3).forEach { preset ->
                    FilterChip(selected = selectedPreset == preset, onClick = { applyPreset(preset) }, label = { Text(preset, style = MaterialTheme.typography.labelSmall) })
                }
            }
            Divider(color = Color.White.copy(.12f))
            Text("10-BAND GRAPHIC EQUALIZER", color = Accent, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.sp)
            val frequencies = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0..4, 5..9).forEach { bandRange ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        bandRange.forEach { index ->
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(frequencies[index], style = MaterialTheme.typography.labelSmall, color = Color.White.copy(.9f), maxLines = 1)
                                Text("${bandValues[index].toInt()} dB", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(.72f), maxLines = 1)
                                Slider(
                                    value = bandValues[index], onValueChange = { value ->
                                        bandValues[index] = value
                                        try {
                                            val effect = eq
                                            if (effect != null && effect.numberOfBands > 0) {
                                                val hardwareBands = effect.numberOfBands.toInt()
                                                val target = if (hardwareBands == 1) 0 else (index * (hardwareBands - 1) / 9f).toInt().coerceIn(0, hardwareBands - 1)
                                                val range = effect.bandLevelRange
                                                val scaled = (value * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                                                effect.setBandLevel(target.toShort(), scaled.toShort())
                                            }
                                        } catch (_: Exception) { }
                                    },
                                    enabled = enabled,
                                    valueRange = -12f..12f,
                                    modifier = Modifier.fillMaxWidth().height(28.dp),
                                    colors = SliderDefaults.colors(thumbColor = listOf(Color(0xFFB9F36A), Color(0xFF20D9D2), Color(0xFFB58CFF), Color(0xFFFF65B5))[index % 4], activeTrackColor = Accent)
                                )
                            }
                        }
                    }
                }
            }
            Text("10 controls shown • actual processing depends on your phone's audio hardware", color = LocalContentColor.current.copy(alpha = .65f), style = MaterialTheme.typography.labelSmall)
            Divider(color = Color.White.copy(.12f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Enable equalizer", fontWeight = FontWeight.SemiBold); Text("Apply selected sound profile", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall) }
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it
                    try { eq?.enabled = it; bassFx?.enabled = it } catch (_: Exception) { }
                })
            }
            Text("Bass boost")
            Slider(value = bass, onValueChange = { bass = it; try { bassFx?.setStrength((it * 1000).toInt().toShort()) } catch (_: Exception) { } },
                enabled = enabled, colors = SliderDefaults.colors(thumbColor = Lilac, activeTrackColor = Lilac))
            Divider(color = Color.White.copy(.12f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Surround sound", fontWeight = FontWeight.SemiBold); Text("Virtualizer effect when supported", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall) }
                Switch(checked = surround, onCheckedChange = { surround = it; try { virtualizer?.enabled = it } catch (_: Exception) { } })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Dolby Audio", fontWeight = FontWeight.SemiBold); Text("Works only if your device provides Dolby processing", color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall) }
                Switch(checked = dolby, onCheckedChange = { dolby = it })
            }
            Text("Audio effects depend on the phone's audio hardware and Android support. Dolby toggle is a preference indicator; actual Dolby processing must be provided by the device.",
                color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
            if (audioSessionId <= 0) Text("Start playback first. Audio effects will attach when a valid audio session is available.", color = Accent, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AnimatedArtworkFrame(art: Uri?, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "artwork-ring")
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(6500, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "artwork-ring-rotation"
    )
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize(.98f).rotate(rotation)
                .border(4.dp, Brush.sweepGradient(listOf(
                    Color(0xFF35E8D1), Color(0xFF8B5CF6), Color(0xFFFF4FA3),
                    Color(0xFFFFC857), Color(0xFFB9F36A), Color(0xFF35E8D1)
                )), CircleShape)
        )
        Box(Modifier.fillMaxSize(.88f).border(1.dp, Color.White.copy(.35f), RoundedCornerShape(27.dp)).padding(5.dp)) {
            AlbumThumb(art, Modifier.fillMaxSize(), large = true)
        }
    }
}

@Composable
private fun AlbumThumb(art: Uri?, modifier: Modifier = Modifier, large: Boolean = false) {
    Box(modifier.clip(RoundedCornerShape(if (large) 30.dp else 14.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF1F7868), Color(0xFFB9F36A)))),
        contentAlignment = Alignment.Center
    ) {
        if (art != null) AsyncImage(model = art, contentDescription = "Album artwork", modifier = Modifier.fillMaxSize())
        else Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(.88f), modifier = Modifier.size(if (large) 90.dp else 28.dp))
    }
}

@Composable
private fun GlassIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(.10f))) {
        Icon(icon, description, tint = Color.White)
    }
}

@Composable
private fun GlassPill(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50.dp)).background(Color.White.copy(.10f))
        .padding(4.dp), verticalAlignment = Alignment.CenterVertically, content = content)
}

@Composable
private fun EmptyState(title: String, message: String, action: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.LibraryMusic, null, tint = Lilac, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(message, color = LocalContentColor.current.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick = action) { Text("Try again") }
    }
}

private fun formatTime(ms: Long): String {
    val seconds = (ms.coerceAtLeast(0L) / 1000L)
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
