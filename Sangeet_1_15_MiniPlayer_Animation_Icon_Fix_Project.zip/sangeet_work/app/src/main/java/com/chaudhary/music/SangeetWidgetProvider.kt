package com.chaudhary.music

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class SangeetWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PLAY_PAUSE, ACTION_NEXT, ACTION_PREVIOUS -> controlPlayback(context, intent.action!!)
            ACTION_REFRESH -> refreshAll(context)
        }
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "com.chaudhary.music.WIDGET_PLAY_PAUSE"
        const val ACTION_NEXT = "com.chaudhary.music.WIDGET_NEXT"
        const val ACTION_PREVIOUS = "com.chaudhary.music.WIDGET_PREVIOUS"
        const val ACTION_REFRESH = "com.chaudhary.music.WIDGET_REFRESH"

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, SangeetWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("widget_state", Context.MODE_PRIVATE)
            val title = prefs.getString("title", "Sangeet — Your music") ?: "Sangeet — Your music"
            val artist = prefs.getString("artist", "Tap to open your library") ?: "Tap to open your library"
            val playing = prefs.getBoolean("playing", false)
            val art = prefs.getString("art", null)
            val views = RemoteViews(context.packageName, R.layout.widget_sangeet)
            views.setTextViewText(R.id.widget_title, title)
            views.setTextViewText(R.id.widget_artist, artist)
            views.setImageViewResource(R.id.widget_art, R.drawable.ic_launcher)
            if (!art.isNullOrBlank()) try { views.setImageViewUri(R.id.widget_art, android.net.Uri.parse(art)) } catch (_: Exception) { }
            views.setImageViewResource(R.id.widget_play, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            views.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(context, 100, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            views.setOnClickPendingIntent(R.id.widget_previous, broadcast(context, ACTION_PREVIOUS, 101))
            views.setOnClickPendingIntent(R.id.widget_play, broadcast(context, ACTION_PLAY_PAUSE, 102))
            views.setOnClickPendingIntent(R.id.widget_next, broadcast(context, ACTION_NEXT, 103))
            manager.updateAppWidget(id, views)
        }

        private fun broadcast(context: Context, action: String, request: Int): PendingIntent =
            PendingIntent.getBroadcast(context, request, Intent(context, SangeetWidgetProvider::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        private fun controlPlayback(context: Context, action: String) {
            val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
            val future = MediaController.Builder(context, token).buildAsync()
            future.addListener({
                try {
                    val controller = future.get()
                    when (action) {
                        ACTION_PLAY_PAUSE -> if (controller.isPlaying) controller.pause() else controller.play()
                        ACTION_NEXT -> controller.seekToNextMediaItem()
                        ACTION_PREVIOUS -> controller.seekToPreviousMediaItem()
                    }
                    refreshAll(context)
                    MediaController.releaseFuture(future)
                } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(context))
        }
    }
}
