package com.chaudhary.music

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF100D19)
private val Panel = Color(0xAA292536)
private val Accent = Color(0xFFFF8A3D)
private val Lilac = Color(0xFFB7A3FF)

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val uri: Uri,
    val art: Uri?,
    val duration: Long
) {
    val key: String get() = id.toString()
}

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { mediaController = controllerFuture?.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, secondary = Lilac, background = Ink,
                    surface = Color(0xFF211D2B), onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                MusicApp(controller = mediaController)
            }
        }
    }

    override fun onDestroy() {
        mediaController?.let { MediaController.releaseFuture(controllerFuture!!) }
        super.onDestroy()
    }
}

@Composable
private fun MusicApp(controller: MediaController?) {
    val context = LocalContext.current
    var permissionGranted by remember { mutableStateOf(hasAudioPermission(context)) }
    var songs by remember { mutableStateOf(emptyList<Song>()) }
    var selectedTab by remember { mutableStateOf("Songs") }
    var selectedSong by remember { mutableStateOf<Song?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showEqualizer by remember { mutableStateOf(false) }
    var backgroundUri by remember {
        mutableStateOf(context.getSharedPreferences("music_ui", 0).getString("background", null))
    }
    var favorites by remember {
        mutableStateOf(context.getSharedPreferences("music_ui", 0).getStringSet("favorites", emptySet())?.toSet() ?: emptySet())
    }
    var search by remember { mutableStateOf("") }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var sleepActive by remember { mutableStateOf(false) }
    var playerTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(controller) {
        while (true) {
            playerTick++
            kotlinx.coroutines.delay(500)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permissionGranted = it
    }
    val backgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            backgroundUri = uri.toString()
            context.getSharedPreferences("music_ui", 0).edit().putString("background", backgroundUri).apply()
        }
    }

    LaunchedEffect(Unit) {
        if (!permissionGranted) {
            val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
            permissionLauncher.launch(p)
        }
    }
    LaunchedEffect(permissionGranted) {
        if (permissionGranted) songs = loadSongs(context)
    }
    LaunchedEffect(sleepActive, sleepMinutes) {
        if (sleepActive && sleepMinutes > 0) {
            kotlinx.coroutines.delay(sleepMinutes * 60_000L)
            controller?.pause()
            sleepActive = false
        }
    }

    val currentUri = controller?.currentMediaItem?.localConfiguration?.uri
    val _playerRefresh = playerTick
    val currentSong = songs.firstOrNull { it.uri == currentUri } ?: selectedSong
    val visibleSongs = when (selectedTab) {
        "Favorites" -> songs.filter { favorites.contains(it.key) }
        "Albums" -> songs.distinctBy { it.album }
        "Artists" -> songs.distinctBy { it.artist }
        else -> songs
    }.filter { it.title.contains(search, true) || it.artist.contains(search, true) || it.album.contains(search, true) }

    Box(Modifier.fillMaxSize().background(
        Brush.linearGradient(listOf(Color(0xFF10101C), Color(0xFF25203B), Color(0xFF111827)))
    )) {
        if (backgroundUri != null) {
            AsyncImage(model = Uri.parse(backgroundUri), contentDescription = null,
                modifier = Modifier.fillMaxSize(), alpha = 0.20f)
            Box(Modifier.fillMaxSize().background(Color(0x990D0B14)))
        }
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Chaudhary Music", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("Your music, your mood", color = Color(0xFFBEB9CA), style = MaterialTheme.typography.bodyMedium)
                }
                GlassIcon(Icons.Default.Search, "Search") { selectedTab = "Songs" }
                Spacer(Modifier.width(8.dp))
                GlassIcon(Icons.Default.Equalizer, "Equalizer") { showEqualizer = true }
                Spacer(Modifier.width(8.dp))
                GlassIcon(Icons.Default.Settings, "Settings") { showSettings = true }
            }
            Spacer(Modifier.height(18.dp))
            if (search.isNotEmpty() || selectedTab == "Songs") {
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search songs, albums, artists") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true, shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = Color.White.copy(.12f),
                        focusedBorderColor = Accent,
                        unfocusedContainerColor = Panel,
                        focusedContainerColor = Panel
                    )
                )
                Spacer(Modifier.height(14.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Songs", "Albums", "Artists", "Favorites").forEach { tab ->
                    FilterChip(
                        selected = selectedTab == tab, onClick = { selectedTab = tab },
                        label = { Text(tab) }, shape = RoundedCornerShape(50.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent.copy(.24f),
                            selectedLabelColor = Color.White,
                            labelColor = Color(0xFFD7D2E2)
                        )
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            if (!permissionGranted) {
                EmptyState("Allow audio access", "Chaudhary Music needs permission to scan music stored on this device.") {
                    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
                    permissionLauncher.launch(p)
                }
            } else if (songs.isEmpty()) {
                EmptyState("No music found", "Add audio files to your device and refresh the library.") {
                    songs = loadSongs(context)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(visibleSongs, key = { it.id }) { song ->
                        SongRow(song, isPlaying = currentSong?.id == song.id && controller?.isPlaying == true) {
                            selectedSong = song
                            playSongList(controller, songs, song)
                        }
                    }
                }
            }
            if (currentSong != null) {
                MiniPlayer(currentSong, controller,
                    onExpand = { selectedSong = currentSong },
                    onNext = { controller?.seekToNextMediaItem() },
                    onPrevious = { controller?.seekToPreviousMediaItem() })
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.Center) {
                GlassPill {
                    Text("LIBRARY", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp))
                    Text("NOW PLAYING", color = Color.White.copy(.76f), fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { currentSong?.let { selectedSong = it } }.padding(horizontal = 18.dp, vertical = 10.dp))
                }
            }
        }

        if (selectedSong != null) {
            NowPlayingDialog(
                song = currentSong ?: selectedSong!!,
                controller = controller,
                isFavorite = favorites.contains((currentSong ?: selectedSong!!).key),
                onFavorite = {
                    val key = (currentSong ?: selectedSong!!).key
                    favorites = favorites.toMutableSet().apply { if (contains(key)) remove(key) else add(key) }
                    context.getSharedPreferences("music_ui", 0).edit().putStringSet("favorites", favorites).apply()
                },
                onClose = { selectedSong = null },
                onEqualizer = { showEqualizer = true }
            )
        }
        if (showSettings) {
            SettingsDialog(
                backgroundUri = backgroundUri,
                onChooseBackground = { backgroundPicker.launch(arrayOf("image/*")) },
                onResetBackground = {
                    backgroundUri = null
                    context.getSharedPreferences("music_ui", 0).edit().remove("background").apply()
                },
                sleepMinutes = sleepMinutes,
                onSleepMinutes = { sleepMinutes = it; sleepActive = it > 0 },
                onDismiss = { showSettings = false }
            )
        }
        if (showEqualizer) EqualizerDialog(context.getSharedPreferences("playback", 0).getInt("audio_session_id", 0), onDismiss = { showEqualizer = false })
    }
}

private fun hasAudioPermission(context: Context): Boolean {
    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
}

private fun loadSongs(context: Context): List<Song> {
    val result = mutableListOf<Song>()
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
    )
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    val cursor: Cursor? = context.contentResolver.query(collection, projection, selection, null, sort)
    cursor?.use {
        val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
        while (it.moveToNext()) {
            val id = it.getLong(idCol)
            val albumId = it.getLong(albumIdCol)
            val uri = Uri.withAppendedPath(collection, id.toString())
            val art = Uri.parse("content://media/external/audio/albumart/$albumId")
            result += Song(id, it.getString(titleCol) ?: "Unknown title",
                it.getString(artistCol) ?: "Unknown artist",
                it.getString(albumCol) ?: "Unknown album", uri, art,
                it.getLong(durationCol))
        }
    }
    return result
}

private fun playSongList(controller: MediaController?, songs: List<Song>, selected: Song) {
    if (controller == null) return
    val items = songs.map { song ->
        MediaItem.Builder().setUri(song.uri).setMediaId(song.id.toString())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist)
                .setAlbumTitle(song.album).setArtworkUri(song.art).build()).build()
    }
    val index = songs.indexOfFirst { it.id == selected.id }.coerceAtLeast(0)
    controller.setMediaItems(items, index, 0L)
    controller.prepare()
    controller.play()
}

@Composable
private fun SongRow(song: Song, isPlaying: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xAA393247), Color(0x77302B40))))
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumThumb(song.art, Modifier.size(54.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text("${song.artist}  •  ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = Color(0xFFBDB7C9), style = MaterialTheme.typography.bodySmall)
        }
        if (isPlaying) Icon(Icons.Default.GraphicEq, null, tint = Accent)
        else Text(formatTime(song.duration), color = Color(0xFFBDB7C9), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun MiniPlayer(song: Song, controller: MediaController?, onExpand: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xDD51405B), Color(0xCC29243A))))
            .clickable(onClick = onExpand).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumThumb(song.art, Modifier.size(48.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(song.artist, color = Color(0xFFC8C2D2), style = MaterialTheme.typography.labelSmall)
        }
        IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null) }
        IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }) {
            Icon(if (controller?.isPlaying == true) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled, null, tint = Accent, modifier = Modifier.size(34.dp))
        }
        IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null) }
    }
}

@Composable
private fun NowPlayingDialog(
    song: Song, controller: MediaController?, isFavorite: Boolean,
    onFavorite: () -> Unit, onClose: () -> Unit, onEqualizer: () -> Unit
) {
    val context = LocalContext.current
    var position by remember { mutableLongStateOf(controller?.currentPosition ?: 0L) }
    var duration by remember { mutableLongStateOf(controller?.duration?.coerceAtLeast(0L) ?: song.duration) }
    val rotation by animateFloatAsState(if (controller?.isPlaying == true) 360f else 0f, label = "recordRotation")
    LaunchedEffect(controller) {
        while (true) {
            position = controller?.currentPosition ?: 0L
            duration = (controller?.duration ?: song.duration).coerceAtLeast(1L)
            kotlinx.coroutines.delay(500)
        }
    }
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().fillMaxHeight(.94f).padding(12.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF30263E), Color(0xFF12111D))))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, null) }
                Text("NOW PLAYING", letterSpacing = 2.sp, style = MaterialTheme.typography.labelMedium, color = Color(0xFFC9C2D1))
                IconButton(onClick = onEqualizer) { Icon(Icons.Default.Equalizer, null) }
            }
            AlbumThumb(song.art, Modifier.fillMaxWidth(.78f).aspectRatio(1f).rotate(rotation / 360f * 4f), large = true)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(song.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = Color(0xFFCAC3D4), style = MaterialTheme.typography.bodyLarge)
            }
            Column {
                Slider(
                    value = position.toFloat().coerceIn(0f, duration.toFloat()),
                    onValueChange = { position = it.toLong() },
                    onValueChangeFinished = { controller?.seekTo(position) },
                    valueRange = 0f..duration.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(position), color = Color(0xFFBDB7C9), style = MaterialTheme.typography.labelSmall)
                    Text(formatTime(duration), color = Color(0xFFBDB7C9), style = MaterialTheme.typography.labelSmall)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onFavorite) { Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (isFavorite) Accent else Color.White) }
                IconButton(onClick = { controller?.seekToPreviousMediaItem() }, modifier = Modifier.size(54.dp)) { Icon(Icons.Default.SkipPrevious, null, modifier = Modifier.size(38.dp)) }
                IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }, modifier = Modifier.size(76.dp).background(Accent, CircleShape)) {
                    Icon(if (controller?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(42.dp))
                }
                IconButton(onClick = { controller?.seekToNextMediaItem() }, modifier = Modifier.size(54.dp)) { Icon(Icons.Default.SkipNext, null, modifier = Modifier.size(38.dp)) }
                IconButton(onClick = onEqualizer) { Icon(Icons.Default.Equalizer, null, tint = Lilac) }
            }
        }
    }
}

@Composable
private fun SettingsDialog(
    backgroundUri: String?, onChooseBackground: () -> Unit, onResetBackground: () -> Unit,
    sleepMinutes: Int, onSleepMinutes: (Int) -> Unit, onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF342A43), Color(0xFF171522))))
                .padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null) }
            }
            Text("PERSONALIZATION", color = Accent, style = MaterialTheme.typography.labelMedium)
            Button(onClick = onChooseBackground, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Choose background photo")
            }
            OutlinedButton(onClick = onResetBackground, enabled = backgroundUri != null, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.RestartAlt, null); Spacer(Modifier.width(8.dp)); Text("Restore default background")
            }
            Divider(color = Color.White.copy(.12f))
            Text("SLEEP TIMER", color = Accent, style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 30, 45, 60).forEach { mins ->
                    FilterChip(selected = sleepMinutes == mins, onClick = { onSleepMinutes(mins) }, label = { Text("$mins min") })
                }
            }
            Text("Chaudhary Music  •  Version 1.0", color = Color(0xFFBDB7C9), style = MaterialTheme.typography.labelSmall)
            Text("Created by Nitin Chaudhary", color = Color(0xFFBDB7C9), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun EqualizerDialog(audioSessionId: Int, onDismiss: () -> Unit) {
    var enabled by remember { mutableStateOf(false) }
    var level by remember { mutableFloatStateOf(0.35f) }
    var bass by remember { mutableFloatStateOf(0.25f) }
    var eq by remember { mutableStateOf<Equalizer?>(null) }
    var bassFx by remember { mutableStateOf<BassBoost?>(null) }
    DisposableEffect(audioSessionId) {
        if (audioSessionId > 0) {
            try {
                eq = Equalizer(0, audioSessionId).apply { enabled = false }
                bassFx = BassBoost(0, audioSessionId).apply { enabled = false }
            } catch (_: Exception) { }
        }
        onDispose {
            try { eq?.release(); bassFx?.release() } catch (_: Exception) { }
            eq = null; bassFx = null
        }
    }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF342A43), Color(0xFF171522))))
                .padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Equalizer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null) }
            }
            Text("10-BAND AUDIO EFFECTS", color = Accent, style = MaterialTheme.typography.labelSmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Enable equalizer", modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it
                    try { eq?.enabled = it; bassFx?.enabled = it } catch (_: Exception) {}
                })
            }
            Text("Equalizer intensity")
            Slider(value = level, onValueChange = {
                level = it
                try {
                    val e = eq
                    if (e != null && e.numberOfBands > 0) {
                        val range = e.bandLevelRange
                        for (b in 0 until e.numberOfBands) {
                            val value = (range[0] + (range[1] - range[0]) * it).toInt()
                            e.setBandLevel(b.toShort(), value.toShort())
                        }
                    }
                } catch (_: Exception) {}
            }, enabled = enabled, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
            Text("Bass boost")
            Slider(value = bass, onValueChange = {
                bass = it
                try { bassFx?.setStrength((it * 1000).toInt().toShort()) } catch (_: Exception) {}
            }, enabled = enabled, colors = SliderDefaults.colors(thumbColor = Lilac, activeTrackColor = Lilac))
            Text(
                if (audioSessionId <= 0) "Start playback first to initialize audio effects."
                else "Audio effects depend on device and Android audio-effect support.",
                color = Color(0xFFBDB7C9), style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun AlbumThumb(art: Uri?, modifier: Modifier = Modifier, large: Boolean = false) {
    Box(modifier.clip(RoundedCornerShape(if (large) 30.dp else 14.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF59426E), Color(0xFFEF8B4C)))),
        contentAlignment = Alignment.Center
    ) {
        if (art != null) AsyncImage(model = art, contentDescription = "Album artwork", modifier = Modifier.fillMaxSize())
        else Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(.88f), modifier = Modifier.size(if (large) 90.dp else 28.dp))
    }
}

@Composable
private fun GlassIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(.10f))) {
        Icon(icon, description, tint = Color.White)
    }
}

@Composable
private fun GlassPill(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50.dp)).background(Color.White.copy(.10f))
        .padding(4.dp), verticalAlignment = Alignment.CenterVertically, content = content)
}

@Composable
private fun EmptyState(title: String, message: String, action: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.LibraryMusic, null, tint = Lilac, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(message, color = Color(0xFFBDB7C9), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick = action) { Text("Try again") }
    }
}

private fun formatTime(ms: Long): String {
    val seconds = (ms.coerceAtLeast(0L) / 1000L)
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
