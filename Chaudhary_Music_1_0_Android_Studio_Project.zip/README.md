# Chaudhary Music 1.0

A native Android offline music player starter project built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features
- Local audio library using MediaStore (device audio permission required)
- Songs, Albums, Artists and Favorites views
- Background playback through Media3 `MediaSessionService`
- Media notification and lock-screen / Bluetooth media controls through MediaSession
- Now Playing screen with seek bar, previous / next, play / pause
- Favorites
- Equalizer intensity control and Bass Boost (device audio-effect support dependent)
- Sleep timer
- Select a custom background image; selection persists across launches
- Premium dark gradient / translucent glass-inspired UI
- Portrait and landscape responsive Compose layout
- No lyrics feature, no online streaming, no video player

## Build APK with GitHub Actions
1. Upload the complete contents of this ZIP to the root of a GitHub repository.
2. Commit to `main` (or `master`).
3. Open **Actions** → **Chaudhary Music APK Build**.
4. Wait for the workflow to finish successfully.
5. Open the successful run and download the `Chaudhary-Music-1.0-APK` artifact.

## Build locally
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then run `app` or execute:
`gradle assembleDebug`

## Notes
- The app scans audio files indexed by Android MediaStore. Files must be available to the Android media library.
- Background playback and system controls are provided by AndroidX Media3 MediaSessionService.
- Equalizer and Bass Boost support depends on the Android device and its audio-effect implementation.
- This source package has not been built on a physical device in this environment. Run the included GitHub Actions workflow to verify compilation in your repository.
