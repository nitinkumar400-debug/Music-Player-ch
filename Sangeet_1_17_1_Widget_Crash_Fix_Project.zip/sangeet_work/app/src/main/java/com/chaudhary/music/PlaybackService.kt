package com.chaudhary.music

import android.content.Intent
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.common.Player
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var player: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        exo.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(eventTime: AnalyticsListener.EventTime, audioSessionId: Int) {
                getSharedPreferences("playback", MODE_PRIVATE).edit().putInt("audio_session_id", audioSessionId).apply()
            }
        })
        exo.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) = updateWidgetState()
            override fun onIsPlayingChanged(isPlaying: Boolean) = updateWidgetState()
            override fun onPlaybackStateChanged(playbackState: Int) = updateWidgetState()
        })
        mediaSession = MediaSession.Builder(this, exo).build()
    }

    private fun updateWidgetState() {
        val p = player ?: return
        val metadata = p.currentMediaItem?.mediaMetadata
        getSharedPreferences("widget_state", MODE_PRIVATE).edit()
            .putString("title", metadata?.title?.toString() ?: "Sangeet — Your music")
            .putString("artist", metadata?.artist?.toString() ?: "Tap to open your library")
            .putString("art", metadata?.artworkUri?.toString())
            .putBoolean("playing", p.isPlaying)
            .apply()
        sendBroadcast(Intent(SangeetWidgetProvider.ACTION_REFRESH).setPackage(packageName))
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.release()
        mediaSession = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
