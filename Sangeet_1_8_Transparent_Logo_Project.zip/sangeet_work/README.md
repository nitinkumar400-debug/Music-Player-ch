# Sangeet 1.6

A focused Android music player for local songs.

## Interface
- Top search icon opens and closes the song search field.
- Animated multi-colour equalizer icon opens sound controls.
- Settings remains available from the top bar.
- Bottom navigation contains only Library and Now Playing.
- Local songs, mini-player, and full now-playing controls.

## Equalizer
Includes Rock, Dance, Pop, Jazz, and Classical preset profiles, Bass Boost, and a Virtualizer-backed Surround Sound option where supported by the device. Dolby Audio is shown as a device-dependent option; actual Dolby processing requires compatible system/vendor support and is not provided by the generic Android API.

## Build
The GitHub Actions workflow builds a debug APK.


## Sangeet 1.7 updates
- Day and Night appearance toggle in Settings (saved across launches).
- Night-mode text uses white content color.
- Now Playing opens as a popup from the bottom navigation and mini player.
- Now Playing uses the current track artwork as a blurred full-screen background.
- Play/Pause control reflects the current playback state.
